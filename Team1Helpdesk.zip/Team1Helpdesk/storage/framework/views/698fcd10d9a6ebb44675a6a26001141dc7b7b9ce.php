<?php $__env->startSection('rightcard'); ?>
      <h1> Done! </h1>
      <a style="color: white" href="/main" class="btn btn-primary btn-lg"><i class="fas fa-check" style="padding-right: 0.5em;"></i>OK</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.empty', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>