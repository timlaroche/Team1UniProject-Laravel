@extends('layouts.empty')

@section('rightcard')
      <h1> Done! </h1>
      <a style="color: white" href="/main" class="btn btn-primary btn-lg"><i class="fas fa-check" style="padding-right: 0.5em;"></i>OK</a>
@endsection