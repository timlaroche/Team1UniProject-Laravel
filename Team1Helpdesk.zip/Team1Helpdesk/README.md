# Team1 Helpdesk Laravel
I put up a quick guide on the repo's Wiki: https://github.com/timlaroche/Team1UniProject-Laravel/wiki/Tim's-Laravel-Intro
